# -*- coding: utf-8 -*-
"""
Created on Fri Oct 23 15:10:53 2020

@author: nickg
"""

import json

def parse_squad_unanswerable_questions(input_json_path='squad-train-v2.0.json',
                                       output_json_path="squad_train_unanswerable.json"):
    unanswerable_questions = {}
    n_questions = 0
    n_unanswerable = 0
    
    with open(input_json_path) as f:
        squad_dict = json.load(f)
        
        # Iterate over every document in the corpus. squad_dict['data'] is a list
        # of documents, where each document is a large dict containing paragraphs
        for doc_itr, document in enumerate(squad_dict['data']):
            print("Document {}: {}".format(doc_itr, document['title']))
            
            # Iterate over every paragraph in the document. 
            # squad_dict['data'][doc_itr]['paragraphs'] is a list of paragraphs,
            # where each paragraph is a large dict containing questions and context
            for par_itr, paragraph in enumerate(document['paragraphs']):
                context = paragraph['context']
                
                # Iterate over each question set for the given context in the
                # paragraph. squad_dict['data'][doc_itr]['paragraphs'][par_itr]['qas']
                # is a list of questions, where each question encodes the text, 
                # id, answer span, and answerability information for the question.
                for q_itr, question in enumerate(paragraph['qas']):
                    n_questions += 1
                    if question['is_impossible'] == True: # Unanswerable question
                        unanswerable_questions[question['id']] = (context, question)
                        n_unanswerable += 1
        
        print("Number of unanswerable questions = {}".format(n_unanswerable))
        print("Number of total questions in dataset = {}".format(n_questions))
        # Print the first 10 unanswerable questions for sanity check
        for k, question in enumerate(unanswerable_questions.values()):
            if k < 10:
                print("{}\n\n".format(question))
            else:
                break
            
        # Dump unanswerable questions to json file
        with open(output_json_path, 'w') as json_file:
            json.dump(unanswerable_questions, json_file)
                
                
parse_squad_unanswerable_questions()